Black King Transport - mobile web app
1. Open index.html on a phone/browser.
2. Data is saved on that device/browser using local storage.
3. Use Add to Home Screen on iPhone/Android for app-like access.
4. This starter version includes 12 vehicle slots, driver auto-fill, diesel, trip/route, KM, dashboard, CSV export and print/PDF.
5. For a true shareable online link and cloud sync between multiple phones, the app needs to be hosted and connected to a database.
